package com.meetpract.emp.service;

import com.meetpract.emp.dto.EmployeeDto;

import java.util.List;

public interface EmployeeService {
    EmployeeDto createEmployee(EmployeeDto employeeDto);
    EmployeeDto getEmployeeById(Long empId);
    List<EmployeeDto> getAllEmployees();
    EmployeeDto updateEmployee(Long empId,EmployeeDto updatedEmployee);
    void deleteEmployee(Long empId);
}
